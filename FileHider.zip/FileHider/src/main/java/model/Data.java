package model;

public class Data {
    private int id;
    private String Filename;
    private String path;
    private String email;

    public Data(int id, String FileName, String path){
        this.id = id;
        this.Filename = FileName;
        this.path = path;

    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getFilename() {
        return Filename;
    }

    public void setFilename(String Filename) {
        Filename = Filename;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Data(int id, String Filename, String path, String email) {
        this.id = id;
        this.Filename = Filename;
        this.path = path;
        this.email = email;


    }
}
